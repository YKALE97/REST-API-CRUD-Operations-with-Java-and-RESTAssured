package App.Nanoapi;

//Imports
import org.testng.annotations.Test;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;

public class Nanocrud {

    public static String baseUrl = "https://jsonplaceholder.typicode.com";
    public static String POST_ENDPOINTS = "/posts";
    public int userId;
    public int createdResourceId;

    @Test(priority = 1)
    void createResource() {
        HashMap<String, Object> requestBody = new HashMap<String, Object>();
        requestBody.put("title", "foo");
        requestBody.put("body", "bar");
        requestBody.put("userId", 1);

        given()
                .contentType(ContentType.JSON)
                .body(requestBody)
        .when()
                .post(baseUrl + POST_ENDPOINTS)
        .then()
                .statusCode(201)
                .log().all();
    }

    @Test(priority = 2, dependsOnMethods = "createResource")
    void updateResource() {
    	if (createdResourceId == 0) {
            System.out.println("Please run createResource() first.");
            return;
        }
        HashMap<String, Object> requestBody = new HashMap<String, Object>();
        requestBody.put("id", createdResourceId);
        requestBody.put("title", "foo-updated");
        requestBody.put("body", "bar-updated");
        requestBody.put("userId", 1);

        given()
                .contentType(ContentType.JSON)
                .body(requestBody)
        .when()
                .put(baseUrl + POST_ENDPOINTS + "/" + createdResourceId)
        .then()
                .statusCode(200)
                .log().all();
    }

    @Test(priority = 3)
    void getResource() {
        given()
        
        .when()
        .get(baseUrl + POST_ENDPOINTS)
        
        .then()
        .statusCode(200)
        .log().all();;
    }

    @Test(priority = 4)
    void deleteResource() {
        given()
        .when()
                .delete(baseUrl + POST_ENDPOINTS + "/" + createdResourceId)
        .then()
                .statusCode(200)
                .log().all();
    }
}